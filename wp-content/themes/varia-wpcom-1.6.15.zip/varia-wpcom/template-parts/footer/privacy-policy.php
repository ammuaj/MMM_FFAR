<?php if ( function_exists( 'the_privacy_policy_link' ) ) {
	the_privacy_policy_link();
}
