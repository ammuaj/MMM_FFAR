<?php
/**
 * Displays header media
 *
 * @package eleven_blog
 */

?>

<div class="custom-header">
	<div class="custom-header-media">
		<?php the_custom_header_markup(); ?>
	</div><!-- .custom-header-media -->
</div><!-- .custom-header -->
