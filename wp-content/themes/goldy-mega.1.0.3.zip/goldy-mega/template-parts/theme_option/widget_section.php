<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package goldy_mega
 */
?>
<div class="woocommerce_product_sections">
	<div class="goldy_mega_product_data">
		<?php dynamic_sidebar('woocommerce_product'); ?>
	</div>		
</div>