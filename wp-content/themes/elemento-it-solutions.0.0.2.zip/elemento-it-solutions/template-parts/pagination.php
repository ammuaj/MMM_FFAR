<?php
	the_posts_pagination( array(
		'prev_text' => esc_html__( 'Previous page', 'elemento-it-solutions' ),
		'next_text' => esc_html__( 'Next page', 'elemento-it-solutions' ),
	) );