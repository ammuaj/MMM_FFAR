<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Elemento IT Solutions
 */
?>

<div class="sidebar-area">
  <?php
    dynamic_sidebar('elemento-it-solutions-sidebar');
  ?>
</div>